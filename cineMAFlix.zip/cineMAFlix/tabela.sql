create database cadastroUsuario;
use cadastroUsuario;
create table usuario (
nome varchar(255),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;
create database cafebistro;

CREATE TABLE filmes (
    id INT NOT NULL AUTO_INCREMENT, 
    genero VARCHAR(45) NOT NULL, 
    nome VARCHAR(45) NOT NULL, 
    sinopse VARCHAR(90) NOT NULL, 
    imagem VARCHAR(80) NOT NULL, 
PRIMARY KEY (id));

INSERT INTO filmes (genero, nome, sinopse, imagem) VALUES ('Açao', 'Clube da Luta', 'Jack (Edward Norton) é um executivo jovem, trabalha como investigador de seguros, mora confortavelmente, mas ele está ficando cada vez mais insatisfeito com sua vida medíocre. Para piorar ele está enfrentando uma terrível crise de insônia, até que encontra uma cura inusitada para o sua falta de sono ao frequentar grupos de auto-ajuda.', 'clubedaluta.png');
INSERT INTO filmes (genero, nome, sinopse, imagem) VALUES ('Terror', 'A hora do pesadelo', 'Um grupo de adolescentes é atacado por um assassino que só pode ser morto no mundo dos sonhos. O assassino é Freddy Krueger, um homem que foi queimado vivo por pais de crianças que ele molestou.Os adolescentes precisam descobrir como derrotar Freddy no mundo dos sonhos, ou ele vai matar todos eles.', 'ahoradopesadelo.jpg');
INSERT INTO filmes (genero, nome, sinopse, imagem) VALUES ('Açao', 'De volta pro futuro', 'Um jovem (Michael J. Fox) aciona acidentalmente uma máquina do tempo construída por um cientista (Christopher Lloyd) em um Delorean, retornando aos anos 50. Lá conhece sua mãe (Lea Thompson), antes ainda do casamento com seu pai, que fica apaixonada por ele. Tal paixão põe em risco sua própria existência, pois alteraria todo o futuro, forçando-o a servir de cupido entre seus pais.', 'devoltapfuturo.jpg');
INSERT INTO filmes (genero, nome, sinopse, imagem) VALUES ('Romance', 'Titanic', 'Um artista pobre e uma jovem rica se conhecem e se apaixonam na fatídica viagem inaugural do Titanic em 1912. Embora esteja noiva do arrogante herdeiro de uma siderúrgica, a jovem desafia sua família e amigos em busca do verdadeiro amor.', 'titanic.jpg');
INSERT INTO filmes (genero, nome, sinopse, imagem) VALUES ('Animaçao', 'Rei Leão', 'Este desenho animado da Disney mostra as aventuras de um leão jovem de nome Simba, o herdeiro de seu pai, Mufasa. O tio malvado de Simba, Oscar, planeja roubar o trono de Mufasa atraindo pai e filho para uma emboscada. Simba consegue escapar e somente Mufasa morre. Com a ajuda de seus amigos,Timon e Pumba, ele reaparece como adulto para recuperar sua terra, que foi roubada por seu tio Oscar.', 'oreileao.jpg');
INSERT INTO filmes (genero, nome, sinopse, imagem) VALUES ('Ficçao', 'Matrix', 'O jovem programador Thomas Anderson é atormentado por estranhos pesadelos em que está sempre conectado por cabos a um imenso sistema de computadores do futuro. À medida que o sonho se repete, ele começa a desconfiar da realidade.', 'matrix.jpg');
INSERT INTO filmes (genero, nome, sinopse, imagem) VALUES ('Animaçao', 'Branca de Neve', 'A rainha malvada morre de ciúmes da beleza de Branca de Neve e manda mata-la. Logo, descobre que a jovem não morreu e está morando na floresta com sete amiguinhos. A princesa então é envenenada pela rainha e só o beijo de um príncipe pode salvá-la.', 'brancade-neve.jpg');