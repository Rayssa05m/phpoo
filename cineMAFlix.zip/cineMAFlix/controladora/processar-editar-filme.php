<?php
require_once "../repositorio/conexao.php";
require '../repositorio/CatalogoRepositorio.php';
require '../modelo/Catalogo.php';
// ...
$filmesRepositorio = new FilmeRepositorio($conn);

if (isset($_POST['editar'])){
    $filme = new Filme($_POST['id'], 
    $_POST['genero'], $_POST['nome'], $_POST['sinopse'], $_POST['imagem']);



    $filmesRepositorio->atualizarFilme($filme);
  //  header("Location: ../visao/admin.php?codedit=$codigo");

    echo "<form id='redirectForm' action='../visao/admin.php' method='POST'>";
    echo "<input type='hidden' name='id' value='{$_POST['id']}'>";
    echo "<input type='hidden' name='tipo' value='{$_POST['tipo']}'>";
    echo "<input type='hidden' name='nome' value='{$_POST['nome']}'>";
    echo "<input type='hidden' name='descricao' value='{$_POST['descricao']}'>";
    echo "<input type='hidden' name='preco' value='{$_POST['preco']}'>";
    echo "</form>";
    echo "<script>document.getElementById('redirectForm').submit();</script>";
}