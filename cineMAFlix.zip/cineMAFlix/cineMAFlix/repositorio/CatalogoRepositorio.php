<?php
class CatalogoRepositorio
{
    private $conn; // Sua conexão com o banco de dados
    public function __construct($conn)
    {
        $this->conn = $conn;
    }
    public function cadastrar(filme $filme)
    {

        $sql = "INSERT INTO filmes (genero, 
    nome, sinopse, imagem, preco) VALUES (?,?,?,?,?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param(
            "ssssd",
            $filme->getGenero(),
            $filme->getNome(),
            $filme->getSinopse(),
            $filme->getImagem(),
            $filme->getPreco()
        );
        $stmt->execute();
        $stmt->close();
    }

    public function listarAlmocos()
    {
        $sql = "SELECT * FROM filmes where genero = 'Almoço' ORDER BY preco";
        $result = $this->conn->query($sql);

        $filmes = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $filme = new filme(
                    $row['id'],
                    $row['genero'],
                    $row['nome'],
                    $row['sinopse'],
                    $row['imagem'],
                    $row['preco']
                );
                $filmes[] = $filme;
            }
        }

        return $filmes;
    }
    public function atualizarfilme(filme $filme)
    {
        if (empty($filme->getImagem())) {
            // Prepara a declaração SQL
            $sql = "UPDATE filmes SET genero = ?, nome = ?,
            sinopse = ?,  preco = ? WHERE id = ?";
            $stmt = $this->conn->prepare($sql);

            // Extrai os atributos do objeto filme
            $genero = $filme->getGenero();
            $nome = $filme->getNome();
            $sinopse = $filme->getSinopse();

            $preco = $filme->getPreco();
            $id = $filme->getId();

            // Vincula os parâmetros
            $stmt->bind_param(
                'sssdi',
                $genero,
                $nome,
                $sinopse,

                $preco,
                $id
            );
            // Executa a declaração preparada
            $resultado = $stmt->execute();

            // Fecha a declaração
            $stmt->close();

            return $resultado;
        } else {
            // Prepara a declaração SQL
            $sql = "UPDATE filmes SET genero = ?, nome = ?,
            sinopse = ?, imagem = ?, preco = ? WHERE id = ?";

            $stmt = $this->conn->prepare($sql);
            // Extrai os atributos do objeto filme
            $genero = $filme->getGenero();
            $nome = $filme->getNome();
            $sinopse = $filme->getSinopse();
            $imagem = $filme->getImagem();
            $preco = $filme->getPreco();
            $id = $filme->getId();

            // Vincula os parâmetros
            $stmt->bind_param(
                'ssssdi',
                $genero,
                $nome,
                $sinopse,
                $imagem,
                $preco,
                $id
            );
            // Executa a declaração preparada
            $resultado = $stmt->execute();

            // Fecha a declaração
            $stmt->close();

            return $resultado;
        }
    }

    public function listarAlmocoPorId($id)
    {
        $sql = "SELECT * FROM filmes WHERE genero = 'Almoço' AND id = ? ORDER BY preco LIMIT 1";

        // Prepara a declaração SQL
        $stmt = $this->conn->prepare($sql);

        // Vincula o parâmetro
        $stmt->bind_param('i', $id);

        // Executa a consulta preparada
        $stmt->execute();

        // Obtém os resultados
        $result = $stmt->get_result();

        $filme = null;

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $filme = new filme(
                $row['id'],
                $row['genero'],
                $row['nome'],
                $row['sinopse'],
                $row['imagem'],
                $row['preco']
            );
        }

        // Fecha a declaração
        $stmt->close();

        return $filme;
    }



    public function listarCafes()
    {
        $sql = "SELECT * FROM filmes where genero = 'Café' ORDER BY preco";
        $result = $this->conn->query($sql);

        $filmes = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $filme = new filme(
                    $row['id'],
                    $row['genero'],
                    $row['nome'],
                    $row['sinopse'],
                    $row['imagem'],
                    $row['preco']
                );
                $filmes[] = $filme;
            }
        }

        return $filmes;
    }

    public function buscarTodos()
    {
        $sql = "SELECT * FROM filmes ORDER BY genero, preco asc";
        $result = $this->conn->query($sql);

        $filmes = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $filme = new filme(
                    $row['id'],
                    $row['genero'],
                    $row['nome'],
                    $row['sinopse'],
                    $row['imagem'],
                    $row['preco']
                );
                $filmes[] = $filme;
            }
        }

        return $filmes;
    }
}
